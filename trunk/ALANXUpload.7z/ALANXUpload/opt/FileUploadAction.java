package com.war.web.actions;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jxl.Sheet;
import jxl.Workbook;
import jxl.format.Colour;
import jxl.write.Label;
import jxl.write.WritableCellFeatures;
import jxl.write.WritableCellFormat;
import jxl.write.WritableWorkbook;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.lang.StringUtils;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import com.manpower.edgesecurity.domain.ESStaffVO;
import com.war.common.BeanLoader;
import com.war.common.StatusUtil;

import com.war.model.WarSearchList;
import com.war.service.WarCandidateService;
import com.war.web.BaseAction;
import com.war.web.forms.ResultExcelModel;

public class FileUploadAction extends BaseAction{
 
	/**
	 * 下载模板或返回结果
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward downloadTemplate(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
		String resultFileName = request.getParameter("resultFileName");
		if(StringUtils.isBlank(resultFileName)){
			String candidateSearchFolder = request.getSession().getServletContext().getRealPath("/")+"candidateSearchFolder";
	    	String candidateSearchTemplate = candidateSearchFolder + "/" + "Candidatedatas Search Template.xls";
	    	File file  = new File(candidateSearchTemplate);
	    	if(file.exists()){
	    		   response.setHeader("Content-Disposition", "attachment; filename=" + file.getName());
	    		   InputStream is = new FileInputStream(file);
	    		   BufferedInputStream bis = new BufferedInputStream(is);
	    		   BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
	    		   org.apache.commons.io.IOUtils.copy(bis,bos);
	    		   
	    		   bis.close();
	    		   bos.close();
	    		   
	    	}
		} else{
			ESStaffVO staff = (ESStaffVO)request.getSession().getAttribute("esStaffVO");
			String candidateSearchFolder = request.getSession().getServletContext().getRealPath("/")+"candidateSearchFolder";
			File file = new File(candidateSearchFolder+ "/" + staff.getStaffName() + "/result/" +resultFileName);
			if(file.exists()&&file.isFile()){
				response.setHeader("Content-Disposition", "attachment; filename=" + file.getName());
			   InputStream is = new FileInputStream(file);
			   BufferedInputStream bis = new BufferedInputStream(is);
			   BufferedOutputStream bos = new BufferedOutputStream(response.getOutputStream());
			   org.apache.commons.io.IOUtils.copy(bis,bos);
			   
			   bis.close();
			   bos.close();
			}
		}
		return null;
	}
	
	
	/**
	 * 删除产生的结果文件
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward deleteResult(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
		String resultFileName = request.getParameter("resultFileName");
		ESStaffVO staff = (ESStaffVO)request.getSession().getAttribute("esStaffVO");
		String candidateSearchFolder = request.getSession().getServletContext().getRealPath("/")+"candidateSearchFolder";
		if(StringUtils.isBlank(resultFileName)){//删除所有的
			File file = new File(candidateSearchFolder+ "/" + staff.getStaffName() + "/result");
			if(file.exists() && file.isDirectory()){
				for(int i = 0; file.list() != null && i < file.list().length; i++){
					file.listFiles()[i].delete();
				}
			}
			
		} else{
			
			File file = new File(candidateSearchFolder+ "/" + staff.getStaffName() + "/result/" +resultFileName);
			file.delete();
		}
		return mapping.findForward("toDownloadResult");
	}
	/**
	 * 显示下载处理结果页面
	 * @param mapping
	 * @param form
	 * @param request
	 * @param response
	 * @return
	 * @throws Exception
	 */
	public ActionForward toDownloadResult(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
		ESStaffVO staff = (ESStaffVO)request.getSession().getAttribute("esStaffVO");
		String candidateSearchFolder = request.getSession().getServletContext().getRealPath("/")+"candidateSearchFolder";
		File file = new File(candidateSearchFolder + "/" + staff.getStaffName()+"/result");
		if(!file.exists() || file.isFile() || file.list() == null || file.list().length == 0)
			return null;
		
		File [] resultFiles = file.listFiles();
		Object[][] resultObjs = new Object[resultFiles.length][2];
		for(int i =0; i < resultFiles.length;i++){
			resultObjs[i][1] = new Date(resultFiles[i].lastModified());
			resultObjs[i][0] = resultFiles[i].getName();
		}
		request.setAttribute("resultObjs", resultObjs);
		return mapping.findForward("toDownloadResult");
	}
	
    /**
     * 批量上传文件
     * 
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @throws Exception 
     */
    @SuppressWarnings("unchecked")
	public ActionForward fileBatchUpload(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response) throws Exception {
    	response.setCharacterEncoding("UTF-8");
    	request.setCharacterEncoding("UTF-8");
    	
    	WarCandidateService candidateService = BeanLoader.getBean(WarCandidateService.class);
    	request.setAttribute("candidateService", candidateService);
    	List<ResultExcelModel> eems = new ArrayList<ResultExcelModel>();
    	//List<WarSearchList> wsls = new ArrayList<WarSearchList>();
    	request.setAttribute("eems", eems);
    	//request.setAttribute("wsls", wsls);
    	ESStaffVO staff = (ESStaffVO)request.getSession().getAttribute("esStaffVO");
    	String candidateSearchFolder = request.getSession().getServletContext().getRealPath("/")+"candidateSearchFolder";
    	PrintWriter pw = null;
    	String fileName = null;
		FileItemFactory factory = new DiskFileItemFactory();
		ServletFileUpload upload = new ServletFileUpload(factory);
		upload.setHeaderEncoding("UTF-8");
		List items = null;

		items = upload.parseRequest(request);
		pw = response.getWriter();
		
			
		System.out.println(request.getSession().getServletContext().getRealPath("/"));
		
			
		for (int i = 0; items != null && i < items.size(); i++) {
			FileItem item = (FileItem) items.get(i);
			if(item.getFieldName() != null && item.getFieldName().equals("Filedata")){
					fileName = item.getName();
		  			BufferedInputStream bis = new BufferedInputStream(item.getInputStream());
		  			this.processUploadExcel(request,staff.getStaffName(), candidateSearchFolder,fileName, bis,pw);
					if(bis != null){
						bis.close();
					}
			}
			
		}
		

		
		
		pw.println("<B>["+fileName+"]处理完毕</B>");
		pw.close();
        return null;
    }

    @SuppressWarnings("unchecked")
	private void processUploadExcel(HttpServletRequest request,String userName, 
    		String candidateSearchFolder, String fileName, BufferedInputStream bis, PrintWriter pw) {
    		
    		List<ResultExcelModel> eems = (List<ResultExcelModel>) request.getAttribute("eems");
    		ResultExcelModel eem = null;
    		/*//step1 保存文件
    		//step1 .如果文件夹不存在，则创建
    		File objFolder = new File(candidateSearchFolder);
    		if(!objFolder.exists()){
    			pw.println("存放上传文件的文件夹不存在，创建该文件夹["+candidateSearchFolder+"]");
				
    			if(!objFolder.mkdir()){
    				pw.println("存放上传文件的文件夹["+candidateSearchFolder+"]不存在，创建失败");
    				return;
    			}
    			pw.println("存放上传文件的文件夹["+candidateSearchFolder+"]创建成功");
				
    		}else if (objFolder.isFile()) {
				if(!objFolder.delete()){
					pw.println("存放上传文件的文件夹["+candidateSearchFolder+"]为文件，删除失败");
					return;
				}
				if(!objFolder.mkdir()){
    				pw.println("存放上传文件的文件夹["+candidateSearchFolder+"]不存在，创建失败");
    				return;
				}
			}*/
    		
    		//step2  如果用户文件夹不存在，则创建
    		File objFolder2 = new File(candidateSearchFolder+"/"+userName);
    		if(!objFolder2.exists()){
    			pw.println("存放上传文件的文件夹["+userName+"]不存在，创建该文件夹");
				
    			if(!objFolder2.mkdirs()){
    				pw.println("系统创建文件夹["+userName+"]失败");
    				return;
    			}
    			pw.println("存放上传文件的文件夹["+userName+"]创建成功");
				
    		}else if (objFolder2.isFile()) {
				if(!objFolder2.delete()){
					if(!objFolder2.mkdir()){
	    				pw.println("系统删除文件["+userName+"]失败");
	    				return;
	    			}
				}
				if(!objFolder2.mkdir()){
    				pw.println("系统创建文件夹["+userName+"]失败");
    				return;
				}
				pw.println("存放上传文件的文件夹["+userName+"]创建成功");
				
			}
    		
    		//step3 如果用户文件存在，则先删除再创建
    		File objFile = new File(candidateSearchFolder+"/"+userName+"/"+ fileName);
    		if(objFile.exists()){
    			if(!objFile.delete()){
    				pw.println("系统删除用户以前上传的同名文件["+fileName+"]失败");
    				return;
    			}
				try {
					if(!objFile.createNewFile()){
	    				pw.println("系统创建文件["+fileName+"]失败");
	    				return;
					}
				} catch (IOException e) {
    				pw.println("系统创建文件["+fileName+"]出现IOException异常");
    				return;
				}
    		}else{
    			try {
    				if(!objFile.createNewFile()){
	    				pw.println("系统创建文件["+fileName+"]失败");
	    				return;
					}
				} catch (IOException e) {
    				pw.println("系统创建文件["+fileName+"]出现IOException异常");
    				return;
				}
    		}
    		
    		
    		BufferedOutputStream bos;
			try {
				bos = new BufferedOutputStream(new FileOutputStream(objFile));
			} catch (FileNotFoundException e) {
				pw.println("系统创建文件的["+fileName+"]没有找到");
				return;
			}
    		//step3 保存文件
    		try {
				org.apache.commons.io.IOUtils.copy(bis,bos);
				bis.close();
				bos.close();
			} catch (IOException e) {
				pw.println("系统将上传的文件["+fileName+"]保存时出先IOException");
				return;
			}
    		
    		//step4. 分析xls文件
			pw.println("分析xls文件["+fileName+"]");
    		Workbook workbook;
			try {
				workbook = Workbook.getWorkbook(objFile);
			} catch (Exception e) {
				pw.println("系统解析文件["+fileName+"]出错，请保证Excel版本为2003及以下，不要使用Excel2007的格式保存，不要在文档中设置保护");
				return;
			} 
			if(workbook == null || workbook.getSheets() == null || workbook.getSheets().length == 0){
				pw.println("系统解析文件["+fileName+"]出错，没有发现Sheet,请保证Excel版本为2003及以下，不要使用Excel2007的格式保存，不要在文档中设置保护");
				return;
			}
    		if(workbook != null && workbook.getSheets() != null && workbook.getSheets().length > 0){
    			pw.println("xls文件["+fileName+"]包含的sheets数量是<b>"+workbook.getSheets().length+"</b>");
    			
    			//检查staff是否存在需要用到
    			WarCandidateService candidateService = (WarCandidateService) request.getAttribute("candidateService");
    			Map<String,Integer> staffNames = (Map<String,Integer>) request.getSession().getAttribute("All_STAFFNAME");
    			if(staffNames == null){
    				staffNames = candidateService.getAllStaffNames();
    				request.getSession().setAttribute("All_STAFFNAME", staffNames);
    			}
    			for(int i = 0; i < workbook.getSheets().length; i++){
    				//解析sheet
    				pw.println("解析[excle:"+fileName+"],[Sheet:"+workbook.getSheets()[i].getName()+"]");
    				this.processSheet(request,workbook.getSheets()[i],i,fileName,pw);
    				
    				
    			}
    			
    		}
    		
    		
    		
    		pw.println("生成报表");
  			
    		//打开一个文件的副本，并且指定数据写回到原文件
    		WritableWorkbook book = null;
    		WritableCellFormat cf = null;
			WritableCellFeatures cellFeatures = null;
			
    		try {
    			System.out.println(objFile.getParent());
    			File outFile = new File(objFile.getParent()+"/result/"+fileName);
    			File outFolder = new File(objFile.getParent()+"/result");
    			if(!outFolder.exists()){
    				outFolder.mkdir();
    			}
    			if(outFile.exists()){
    				outFile.delete();
    				outFile.createNewFile();
    			}
				book = Workbook.createWorkbook(outFile,workbook);
				
				for(int i = 0; eems !=null && i < eems.size(); i++ ){
					ResultExcelModel rem = eems.get(i);
					
					int sheetId = rem.getSheetId();
					int rowId = rem.getRowId();
					
					
					//如果整行出错,整行表位红色，在第16列添加出错原因
					if(!rem.isSuccess()){
						for(int ii = 0; ii < 15; ii++){
							cf = new WritableCellFormat();
							cf.setBackground(Colour.RED);
							book.getSheet(sheetId).getWritableCell(ii, rowId).setCellFormat(cf);
						}
						System.out.println(rem.getReason());
						book.getSheet(sheetId).addCell(new Label(15,rowId,rem.getReason()));
					}
					
					//遍历单元格，检查某个单元格出错，该单元格表红色，并添加批注，说明错误原因
					for(int ii = 0; ii < 15; ii++){
						if(!rem.getCellsuccess()[ii]){
							
							//cf = new WritableCellFormat(book.getSheet(sheetId).getWritableCell(ii, rowId).getCellFormat());
							cf = new WritableCellFormat();
							cf.setBackground(Colour.RED);
							//cellFeatures = new WritableCellFeatures(); 
							//System.out.println(rem.getReasons()[ii]);
							//cellFeatures.setComment(rem.getReasons()[ii],100,100);
							 
							//String content = workbook.getSheet(sheetId).getCell(ii, rowId) == null? null:workbook.getSheet(sheetId).getCell(ii, rowId).getContents();
							//book.getSheet(sheetId).getWritableCell(ii, rowId).setCellFeatures(cellFeatures);
							if(book.getSheet(sheetId).getWritableCell(ii, rowId) !=null){
								book.getSheet(sheetId).getWritableCell(ii, rowId).setCellFormat(cf);
							}
							
							//Label label = new Label(ii, rowId, content);
							//label.setCellFormat(cf);
							//label.setCellFeatures(cellFeatures);
							book.getSheet(sheetId).addCell(new Label(15,rowId,rem.getReason()));
						}
					}
					
				}
				
				book.write();
				book.close();
				
			} catch (Exception e) {
				e.printStackTrace();
				pw.println("系统修改文件["+fileName+"]出错，请保证Excel版本为2003及以下，不要使用Excel2007的格式保存，不要在文档中设置保护");
			} 
  			
  			if(workbook != null){
    			workbook.close();
    		}
  			
  			
  			
    }
    
    @SuppressWarnings("unchecked")
	private void processSheet(HttpServletRequest request,Sheet sheet, int sheetPosition, String fileName, PrintWriter pw){
    	WarCandidateService candidateService = (WarCandidateService) request.getAttribute("candidateService");
    	List<ResultExcelModel> eems = (List<ResultExcelModel>) request.getAttribute("eems");
    	//List<WarSearchList> wsls = (List<WarSearchList>) request.getAttribute("wsls");
    	Map<String,Integer> staffNames = (Map<String,Integer>) request.getSession().getAttribute("All_STAFFNAME");
    	//step1 验证sheet是否合格,至少有15列，至少有2行(第一行为标题)
    	if(sheet == null || sheet.getRows()< 2 || sheet.getColumns()<15){
    		pw.println("Excel中的每个Sheet中至少应该有2行内容，第一行必须为标题，至少必须有15列（到O列）,请检查模板的正确性");
    		return;
    	}
    	
    	//int zzz = 1;
    	if(sheet != null && sheet.getRows() >= 2 && sheet.getColumns() >=15){
    		
    		for(int i = 1; i < sheet.getRows(); i++){
    			ResultExcelModel sem = new ResultExcelModel();
    			try {
	    			//如果是空白行,跳过
	    			boolean blackFlag = true;
	    			for(int j = 0; j < 15; j++){
	    				if(sheet.getRow(i).length >j && sheet.getRow(i)[j] != null && StringUtils.isNotBlank(sheet.getRow(i)[j].getContents())){
	    					blackFlag = false;
	    					break;
	    				}
	    			}
	    			if(blackFlag) continue;
	    			
	    			
	    			String servRep = sheet.getRow(i).length<1 || sheet.getRow(i)[0] == null ? null : sheet.getRow(i)[0].getContents();
	    			String name = sheet.getRow(i).length<2 || sheet.getRow(i)[1] == null ? null : sheet.getRow(i)[1].getContents();
	    			String phone = sheet.getRow(i).length<3 || sheet.getRow(i)[2] == null ? null :	sheet.getRow(i)[2].getContents();
	    			String mobile = sheet.getRow(i).length<4 || sheet.getRow(i)[3] == null ? null :	sheet.getRow(i)[3].getContents();
	    			String company = sheet.getRow(i).length<5 || sheet.getRow(i)[4]	 == null ? null : sheet.getRow(i)[4].getContents();
	    			String gender =	sheet.getRow(i).length<6 || sheet.getRow(i)[5] == null ? null : sheet.getRow(i)[5].getContents();
	    			String industry =	sheet.getRow(i).length<7 || sheet.getRow(i)[6]   == null ? null :  sheet.getRow(i)[6].getContents();
	    			String skillPractice =sheet.getRow(i).length<8 || sheet.getRow(i)[7] == null ? null : sheet.getRow(i)[7].getContents();
	    			String title =sheet.getRow(i).length<9 || sheet.getRow(i)[8] == null ? null : sheet.getRow(i)[8].getContents();
	    			String salaryExpectation =sheet.getRow(i).length<10 || sheet.getRow(i)[9] == null ? null : sheet.getRow(i)[9].getContents();
	    			String workingExperience = sheet.getRow(i).length<11 || sheet.getRow(i)[10] == null ? null : sheet.getRow(i)[10].getContents();
	    			String city = sheet.getRow(i).length<12 || sheet.getRow(i)[11] == null ? null :sheet.getRow(i)[11].getContents();
	    			String remark =sheet.getRow(i).length<13 || sheet.getRow(i)[12] == null ? null : sheet.getRow(i)[12].getContents();
	    			String source = sheet.getRow(i).length<14 || sheet.getRow(i)[13] == null ? null : sheet.getRow(i)[13].getContents();
	    			String email =sheet.getRow(i).length<15 || sheet.getRow(i)[14] == null ? null :sheet.getRow(i)[14].getContents();
	    			
	    			
					
					
					
	    			//pw.println("逐条解析[excle:"+fileName+"],[Sheet:"+sheet.getName()+"],第<b>"+zzz+"</b>条");
	    			//zzz++;
	
	    			boolean flag = true;
	    			
	    			StringBuffer sbError = new StringBuffer("");
	    			//验证serv rep
	    			if(StringUtils.isBlank(servRep)){
	    				flag = false;
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",A]" + "Serv Rep必须填写，不能为空或空字符串;";
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[0] = false;
	    	    		sem.getReasons()[0] = errorS;
	    				
	    			}else{
						
		    			if(staffNames == null || !staffNames.containsKey(StringUtils.trimToNull(servRep.toUpperCase()))){
							flag = false;
		    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",A]" + "Serv Rep在数据库中不存在，请检查Serv Rep的正确性;";
		    	    		sbError.append(errorS);
		    	    		pw.println(errorS);
		    	    		sem.getCellsuccess()[0] = false;
		    	    		sem.getReasons()[0] = errorS;
						}
	    			}
	    			
	    			//验证CandidateName
	    			
	    			if(StringUtils.isBlank(name)){
	    				flag = false;
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",B]" + "Name必须填写，不能为空或空字符串;";
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[1] = false;
	    	    		sem.getReasons()[1] = errorS;
	    			}
	    			
	    			//验证手机或电话
	    			
	    			if(StringUtils.isBlank(phone)&& StringUtils.isBlank(mobile)){
	    				flag = false;
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",C or D]" + "Phone和Mobile必须填写至少一项;";
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[2] = false;
	    	    		sem.getReasons()[2] = errorS;
	    			}
	    			
	    			//通过手机电话和CandidateName判断该用户是否已经存在
	    			// 名字 + 电话 不能重复
	    	        if (StringUtils.isNotBlank(phone)) {
	    	            List list = candidateService.findSearchListByNameAndPhone(name, phone);
	    	            if (list != null && list.size() > 0) {
	    	            	flag = false;
	        	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] " + "数据库中已经存在本条记录:[CandidateName="+name+"],[CandidatePhone="+phone+"];";
	        	    		sbError.append(errorS);
	        	    		pw.println(errorS);
	        	    		sem.getCellsuccess()[1] = false;
	        	    		sem.getReasons()[1] = sem.getReasons()[1] + errorS;
	        	    		sem.getCellsuccess()[2] = false;
	        	    		sem.getReasons()[2] = errorS;
	    	            }
	    	        }
	
	    	        // 名字 + 手机号 不能重复
	    	        if (StringUtils.isNotBlank(mobile)) {
	    	            List list = candidateService.findSearchListByNameAndMobile(name, mobile);
	    	            if (list != null && list.size() > 0) {
	    	            	flag = false;
	        	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] " + "数据库中已经存在本条记录:[CandidateName="+name+"],[CandidatePhone="+mobile+"];";
	        	    		sbError.append(errorS);
	        	    		pw.println(errorS);
	        	    		sem.getCellsuccess()[1] = false;
	        	    		sem.getReasons()[1] = sem.getReasons()[1] + errorS;
	        	    		sem.getCellsuccess()[3] = false;
	        	    		sem.getReasons()[3] = errorS;
	    	            }
	    	        }
	
	    			//验证Company
	    	        
	    			if(StringUtils.isBlank((company))){
	    				flag = false;
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",E] " + "Company必须填写，不能为空或空字符串;";
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[4] = false;
	    	    		sem.getReasons()[4] = errorS;
	    			}
	    			
	    			
	    			//验证Industry
	    			
	    			if(StringUtils.isNotBlank(industry) && !StatusUtil.getIndustryMaps().containsKey(industry)){
	    				flag = false;
	    	    		StringBuffer temp = new StringBuffer("Industry可以不填写，填写必须是[");
	    	    		int iflag = 0;
	    	    		for(String str:StatusUtil.getIndustryMaps().keySet()){
	    	    			iflag++;
	    	    			if(StatusUtil.getIndustryMaps().keySet().size()== iflag)
	    	    				temp.append(str).append("、");
	    	    			else
	    	    				temp.append(str);
	    	    		}
	    	    		temp.append("]中的一个;");
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",G] " + temp.toString();
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[6] = false;
	    	    		sem.getReasons()[6] =  errorS;
	    			}
	    			
	    			//验证SkillPractice
	    			
	    			if(StringUtils.isNotBlank(skillPractice) && !StatusUtil.getSkillPracticeMaps().containsKey(skillPractice)){
	    				flag = false;
	    	    		StringBuffer temp = new StringBuffer("SkillPractice可以不填写，填写必须是[");
	    	    		int iflag = 0;
	    	    		for(String str:StatusUtil.getSkillPracticeMaps().keySet()){
	    	    			iflag++;
	    	    			if(StatusUtil.getIndustryMaps().keySet().size()== iflag)
	    	    				temp.append(str).append("、");
	    	    			else
	    	    				temp.append(str);
	    	    		}
	    	    		temp.append("]中的一个;");
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",H] " + temp.toString();
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[7] = false;
	    	    		sem.getReasons()[7] = errorS;
	    			}
	    			
	    			//验证Title
	    			
	    			if(StringUtils.isBlank(title)){
	    				flag = false;
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",I] " + "Title必须填写，不能为空或空字符串;";
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[8] = false;
	    	    		sem.getReasons()[8] = errorS;
	    				
	    			}
	    			//验证SalaryExpectation
	    			
	    			if(StringUtils.isNotBlank(salaryExpectation) && !StatusUtil.getSalaryExpectationMaps().containsKey(salaryExpectation)){
	    				flag = false;
	    	    		StringBuffer temp = new StringBuffer("SalaryExpectation可以不填写，填写必须是[");
	    	    		int iflag = 0;
	    	    		for(String str:StatusUtil.getSalaryExpectationMaps().keySet()){
	    	    			iflag++;
	    	    			if(StatusUtil.getSalaryExpectationMaps().keySet().size()== iflag)
	    	    				temp.append(str).append("、");
	    	    			else
	    	    				temp.append(str);
	    	    		}
	    	    		temp.append("]中的一个;");
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",J] " + temp.toString();
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[9] = false;
	    	    		sem.getReasons()[9] = errorS;
	    				
	    			}
	    			//验证WorkingExperience
	    			
	    			if(StringUtils.isNotBlank(workingExperience) && !StatusUtil.getWorkingExperienceMaps().containsKey(workingExperience)){
	    				flag = false;
	    	    		StringBuffer temp = new StringBuffer("WorkingExperience可以不填写，填写必须是[");
	    	    		int iflag = 0;
	    	    		for(String str:StatusUtil.getWorkingExperienceMaps().keySet()){
	    	    			iflag++;
	    	    			if(StatusUtil.getIndustryMaps().keySet().size()== iflag)
	    	    				temp.append(str).append("、");
	    	    			else
	    	    				temp.append(str);
	    	    		}
	    	    		temp.append("]中的一个;");
	    	    		String  errorS = "文件["+fileName+"] Sheet["+sheet.getName()+"] Cell["+(i+1)+",K] " + temp.toString();
	    	    		sbError.append(errorS);
	    	    		pw.println(errorS);
	    	    		sem.getCellsuccess()[10] = false;
	    	    		sem.getReasons()[10] = errorS;
	    			}
	    			
	   
	    			//上面有一个条件不满足，则不再继续下去，跳到下一行
	    			if(flag){
	    			//满足上面所有条件，往数据库中插入数据
	    				Date date = new Date();
	    				WarSearchList wsl = new WarSearchList();
	    				
	    				wsl.setCandidateName(StringUtils.trimToNull(name));
	    				wsl.setCandidatePhone(StringUtils.trimToNull(phone));
	    				wsl.setCandidateMobile(StringUtils.trimToNull(mobile));
	    				wsl.setCandidateCompany(StringUtils.trimToNull(company));
	    				wsl.setGender(StringUtils.trimToNull(gender));
	    				wsl.setIndustry(StatusUtil.getIndustryMaps().get(StringUtils.trimToNull(industry)));
	    				wsl.setSkillPractice(StatusUtil.getSkillPracticeMaps().get(StringUtils.trimToNull(skillPractice)));
	    				wsl.setTitle(StringUtils.trimToNull(title));
	    				wsl.setSalaryExpectation(StatusUtil.getSalaryExpectationMaps().get(StringUtils.trimToNull(salaryExpectation)));
	    				wsl.setWorkingExperience(StatusUtil.getWorkingExperienceMaps().get(StringUtils.trimToNull(workingExperience)));
	    				wsl.setCity(StringUtils.trimToNull(city));
	    				wsl.setRemark(StringUtils.trimToNull(remark));
	    				wsl.setSource(StringUtils.trimToNull(source));
	    				wsl.setEmail(StringUtils.trimToNull(email));
	    				
	    				wsl.setCreateBy(staffNames.get(StringUtils.trimToNull(servRep.toUpperCase())).toString());
	    				wsl.setCreateDate(date);
	        			wsl.setModifyBy(staffNames.get(StringUtils.trimToNull(servRep.toUpperCase())).toString());
	        			wsl.setModifyDate(date);
	        			
	    				wsl.setStatus("-100");//表示批量插入的数据
	        			//wsl.setCandidateDescription(candidateDescription);
						//wsl.setCandidateNumber(candidateNumber);
						//wsl.setCandidatePosition(candidatePosition);
						//wsl.setCandidateReportName(candidateReportName);
						//wsl.setCandidateReportPath(candidateReportPath);
						//wsl.setCandidateReportTimes(candidateReportTimes);
						//wsl.setChangeable(changeable);
						//wsl.setContactPerson(contactPerson);
						//wsl.setCandidateResumeLastBy(servRep);
						//wsl.setCandidateReportLastBy(servRep);
						//wsl.setCandidateReportLastDate(d);
						//wsl.setSource(source);
	    				
		    			
	    				System.out.print(wsl.getCandidateName()+"--------");	
						candidateService.saveSearchList(wsl);
						System.out.println(wsl.getCandidateName());
	        			System.out.println();
						//wsls.add(wsl);
						
	    			}else{
	    				//以excel的sheet 位置和行号为id
						sem.setSheetId(sheetPosition);
						sem.setRowId(i);
						sem.setServRep(servRep);
						sem.setName(name);
						sem.setPhone(phone);
						sem.setMobile(mobile);
						sem.setCompany(company);
						sem.setGender(gender);
						sem.setIndustry(industry);
						sem.setSkillPractice(skillPractice);
						sem.setTitle(title);
						sem.setSalaryExpectation(salaryExpectation);
						sem.setWorkingExperience(workingExperience);
						sem.setCity(city);
						sem.setRemark(remark);
						sem.setSource(source);
						sem.setEmail(email);
						//以excel的sheet 位置和行号为id
						sem.setSheetId(sheetPosition);
						sem.setRowId(i);
						sem.setReason(sbError.toString());
						sem.setSuccess(true);
						eems.add(sem);
					}
    			} catch (Exception e) {
    				e.printStackTrace();
					sem.setSuccess(false);
					sem.setReason("保存至数据库时是出现异常" + e.getMessage());
					eems.add(sem);
					
				}
    		}
    		
    	}
    	
    	
    	
    	
		
		
		
    }

}
