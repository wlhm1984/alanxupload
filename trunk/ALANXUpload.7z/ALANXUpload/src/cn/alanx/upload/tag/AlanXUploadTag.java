/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cn.alanx.upload.tag;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.PageContext;
import javax.servlet.jsp.tagext.Tag;

/**
 *
 * @author alan.xiao
 */
public class AlanXUploadTag implements Tag{
    private PageContext pageContext;
    private Tag parent;
    @Override
    public void setPageContext(PageContext pageContext) {
        this.pageContext = pageContext;
        
    }

    @Override
    public void setParent(Tag parent) {
       this.parent = parent;
    }

    @Override
    public Tag getParent() {
        return  parent;
    }

    @Override
    public int doStartTag() throws JspException {
        return Tag.SKIP_BODY;
    }

    @Override
    public int doEndTag() throws JspException {
        try {
            pageContext.getOut().write("Hello");
        } catch (IOException ex) {
            Logger.getLogger(AlanXUploadTag.class.getName()).log(Level.SEVERE, null, ex);
        }
        return Tag.EVAL_PAGE;
    }

    @Override
    public void release() {
        //todo
    }

}
